let products=[], cart=[];
const money = v => v.toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const $ = id => document.getElementById(id);

async function init(){
  products = await fetch('/api/products').then(r=>r.json());
  renderProducts();
  renderCart();
}
function renderProducts(){
  $('products').innerHTML = products.map(p => `
    <article class="card">
      <div class="pic">Produto</div>
      <h3>${p.name}</h3>
      <div class="price">${money(p.price)}</div>
      <button class="primary" onclick="add(${p.id})">Adicionar ao carrinho</button>
    </article>`).join('');
}
function add(id){
  const found=cart.find(x=>x.id===id);
  if(found) found.qty++;
  else cart.push({id,qty:1});
  renderCart();
  $('cart').classList.add('open');
}
function renderCart(){
  const rows=cart.map(i=>{
    const p=products.find(x=>x.id===i.id);
    return `<div class="cartItem"><span>${p.name} × ${i.qty}</span><strong>${money(p.price*i.qty)}</strong></div>`;
  }).join('');
  $('cartItems').innerHTML=rows || '<p>Seu carrinho está vazio.</p>';
  const subtotal=cart.reduce((s,i)=>s+products.find(p=>p.id===i.id).price*i.qty,0);
  $('subtotal').textContent=money(subtotal);
  $('total').textContent=money(subtotal);
  $('count').textContent=cart.reduce((s,i)=>s+i.qty,0);
}
$('cartBtn').onclick=()=> $('cart').classList.add('open');
$('closeCart').onclick=()=> $('cart').classList.remove('open');
$('checkoutBtn').onclick=()=>{
  if(!cart.length) return alert('Adicione pelo menos um produto.');
  $('checkout').classList.add('show');
};
$('closeCheckout').onclick=()=> $('checkout').classList.remove('show');

$('checkoutForm').addEventListener('submit', async e=>{
  e.preventDefault();
  const f=new FormData(e.target);
  const payment=f.get('payment');
  const customer={
    name:f.get('name'),phone:f.get('phone'),
    address:`${f.get('street')}, ${f.get('city')} - ${f.get('state')}, CEP ${f.get('zip')}`
  };
  const order=await fetch('/api/orders',{
    method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({items:cart,customer,paymentMethod:payment})
  }).then(r=>r.json());
  $('result').innerHTML=`<div class="success"><strong>Pedido ${order.id} criado!</strong><br>Total: ${money(order.total)}<br><small>O gateway de pagamento real deve ser conectado nesta etapa.</small></div>`;
  cart=[]; renderCart();
});
init();
