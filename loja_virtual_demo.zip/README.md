# Loja Virtual Demo

Projeto-base de e-commerce para produtos permitidos, com:
- catálogo e carrinho
- desconto automático de 10% no Pix
- checkout com endereço de entrega
- opções Pix, cartão e boleto (modo demonstração)
- API Node/Express
- pedidos salvos localmente em JSON

## Rodar
1. Instale Node.js 18+.
2. Execute `npm install`.
3. Execute `npm start`.
4. Abra `http://localhost:3000`.

## Pagamentos reais
As rotas de pagamento estão preparadas como demonstração. Para cobrar de verdade, conecte um gateway compatível com sua conta e credenciais, mantendo as chaves somente no servidor.
